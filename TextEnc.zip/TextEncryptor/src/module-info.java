/**
 * 
 */
/**
 * 
 */
module TextEncryptor {
}